# Dino Jump — Hướng dẫn cài đặt và build file APK

Đây là toàn bộ mã nguồn của game. Vì việc build ra file `.apk` thật sự cần
có Flutter SDK và Android SDK được cài trên chính máy của bạn (việc này
không thể làm thay từ xa), hãy làm theo các bước dưới đây trên máy tính
của bạn. Toàn bộ các bước chỉ cần copy & dán lệnh, không cần biết code.

## Bước 0 — Cài công cụ (chỉ làm một lần)

1. Cài **Flutter SDK**: làm theo hướng dẫn chính thức tại
   https://docs.flutter.dev/get-started/install (chọn hệ điều hành của bạn).
2. Cài **Android Studio** (https://developer.android.com/studio) — dùng để
   có Android SDK, công cụ build và máy giả lập (emulator) để chạy thử.
3. Mở terminal, chạy lệnh sau để kiểm tra mọi thứ đã sẵn sàng:
   ```
   flutter doctor
   ```
   Nếu có dòng nào báo lỗi (dấu ✗ màu đỏ), làm theo hướng dẫn mà nó in ra.

## Bước 1 — Tạo project Flutter trống

Trong terminal, di chuyển đến thư mục bạn muốn chứa project rồi chạy:

```
flutter create dino_jump
cd dino_jump
```

Lệnh này tự sinh ra toàn bộ phần "khung xương" của một app Flutter
(thư mục `android/`, `ios/`, file `pubspec.yaml` đúng với phiên bản
Flutter bạn vừa cài...). Đây là lý do bạn KHÔNG cần tôi gửi các thư mục
`android/`, `ios/` — để chúng tự sinh ra chính xác theo máy của bạn sẽ an
toàn hơn nhiều so với việc tôi soạn tay.

## Bước 2 — Thêm thư viện vào pubspec.yaml

Mở file `pubspec.yaml` mà `flutter create` vừa sinh ra, tìm đến phần
`dependencies:` và thêm 2 dòng sau vào ngay dưới `flutter: sdk: flutter`:

```yaml
dependencies:
  flutter:
    sdk: flutter
  flame: ^1.37.0
  shared_preferences: ^2.5.5
```

(Nếu bạn muốn chắc chắn 100%, có thể dùng file `pubspec.yaml` mẫu đầy đủ
đi kèm trong gói này, copy đè lên file vừa được tạo.)

## Bước 3 — Chép mã nguồn vào project

Xoá nội dung thư mục `lib/` mà `flutter create` vừa sinh ra (chỉ có 1 file
`main.dart` mẫu), rồi chép toàn bộ thư mục `lib/` đi kèm trong gói này vào
đúng vị trí đó. Sau khi chép xong, cấu trúc phải như sau:

```
dino_jump/
├── pubspec.yaml
└── lib/
    ├── main.dart
    ├── theme/
    │   └── app_theme.dart
    ├── services/
    │   └── score_storage_service.dart
    ├── game/
    │   ├── dino_runner_game.dart
    │   └── components/
    │       ├── background_sky.dart
    │       ├── obstacle.dart
    │       ├── obstacle_spawner.dart
    │       ├── player_dino.dart
    │       └── scrolling_ground.dart
    └── ui/
        ├── game_screen.dart
        ├── game_over_dialog.dart
        └── score_badge.dart
```

## Bước 4 — Tải thư viện

Trong terminal, tại thư mục gốc của project (`dino_jump/`), chạy:

```
flutter pub get
```

## Bước 5 — Chạy thử trên máy giả lập hoặc điện thoại

Bật một máy giả lập Android (qua Android Studio) hoặc cắm điện thoại thật
vào máy tính (nhớ mở "USB debugging" trong điện thoại), sau đó chạy:

```
flutter run
```

Chạm vào màn hình để khủng long nhảy. Game sẽ tự lưu Điểm Cao Nhất và lịch
sử 3 trận gần nhất ngay trên máy, không cần mạng internet.

## Bước 6 — Build file APK để cài đặt

Khi đã hài lòng, chạy lệnh sau để đóng gói ra file `.apk`:

```
flutter build apk --release
```

Sau khi build xong, file APK nằm tại:

```
build/app/outputs/flutter-apk/app-release.apk
```

Chép file này vào điện thoại Android (qua cáp USB, Google Drive, Zalo...)
và mở để cài đặt (có thể cần bật "Cho phép cài ứng dụng từ nguồn không
xác định" trong phần Cài đặt của điện thoại).

## Ghi chú về gameplay

- Chạm màn hình lần đầu để bắt đầu trò chơi.
- Chạm màn hình để khủng long nhảy qua chướng ngại vật.
- Tốc độ trò chơi sẽ tăng dần theo thời gian, điểm số tăng theo quãng
  đường đã đi được.
- Khi va vào chướng ngại vật, một bảng thông báo sẽ hiện ra với điểm số
  vừa đạt, điểm cao nhất, lịch sử 3 trận gần nhất và nút "CHƠI LẠI".
